#pragma once
#include "esp_wifi.h"

esp_err_t esp32_deauther_configure_wifi(uint8_t channel);

