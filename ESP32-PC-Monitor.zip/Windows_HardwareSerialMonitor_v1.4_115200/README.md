# HardwareSerialMonitor
Gnat Stats PC Harware Performance Monitor Windows Client
  
  GNATSTATS OLED PC Performance Monitor / HardwareSerialMonitor -  Rupert Hirst & Colin Conway © 2016-2018
  http://tallmanlabs.com  & http://runawaybrainz.blogspot.com/
  
  https://hackaday.io/project/19018-gnat-stats-tiny-oled-pc-performance-monitor

  Licence
  -------
  
  GPL v2
  
Gnat-Stats, Phat-Stats & Hardware Serial Monitor 
Copyright (C) 2016  Colin Conway, Rupert Hirst and contributors
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; If not, see <http://www.gnu.org/licenses/>.


